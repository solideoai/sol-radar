# Task4 live UI continuation — preparation only

Prepared 2026-10-19. Owner: `people_live_ui_fix`. Checkout: `/Users/leegwanghui/.codex/worktrees/5b0c/sol-radar`, branch `feat/people-read`, frozen source `f579a2a6b27fb0ab05650179aba6609a5fb07182`. Initial `git status --short` was empty. No product/test/config changes, tests, app processes, or DB commands have been run by this continuation. Only this ignored report is written. Await explicit root GO after the actual QA owner finishes and cleans up.

## Binding interpretation

- This is a correction of two new actual-runtime findings, not a restart or broad review of Tasks1–3A. User design §5/§7/Appendix A remains binding. Keep the earlier I1 landmark and M3 finder fixes untouched.
- Preserve exact accessible person-button names `${name} 상세 보기`, real native button Enter/Space behavior, whole-card pointer activation, Drawer trigger/focus restoration, visible 44px Avatar/title/scoring badge, and screen-reader access to useful metadata.
- Preserve exact department and `상위 미지정` button names too: the existing browser and live E2E locators use those names, and no requirement justifies silently changing them.
- Preserve all directory/model/server/Auth/API/SQL/photo/token/package/guardrail files and existing selection, URL, finder, bundle, hierarchy, count and column behavior.
- Freeze prohibits reproducing or measuring runtime now. The left-pane concern is not yet a confirmed DOM-measured defect.

## A. Confirmed historical default whole-document axe failure

Actual source receipt: `/Users/leegwanghui/dev/hackathon/sol-radar-inputs/people-read-20261018/qa/day19-target/safe-people-pending25-f579a2a6b27f/axe-chart-1440.json`. Its index identifies source SHA f579 and SHA-256 `1b9c68005ba9cbc725cc0bd7dd20d0447ecc90c602fbc87c86b90a0461c34620`.

The JSON is an array of violations, containing one serious `label-content-name-mismatch` violation with **41 nodes: 35 department buttons, 1 unknown-summary button, and 5 person cards**. The first target is `button[aria-label="AX사업본부"]`; the card targets include `#org-person-5c66f539-c61d-5a6e-b30e-c3843259f9b5`. This receipt must remain a FAIL in the final evidence. Whole-document chart axe has not passed on f579. List/Drawer zero-violation receipts do not imply chart-page success; the chart Drawer screenshot was a loading-state image.

Root cause is in `web/components/people/org-chart.tsx`:

- Department team/disclosure buttons explicitly name only the department while visibly containing its member count.
- The unknown-summary button explicitly names only `상위 미지정` while visibly containing the department/member counts.
- A person card explicitly names only `${name} 상세 보기` while visibly containing name, title, scoring text, and possibly the Avatar fallback initial.

Inspected the actual installed `axe-core@4.14.0/axe.js` (resolved through the same installed `eslint-plugin-jsx-a11y` dependency used by `readInstalledAxeSource`). `labelContentNameMismatchEvaluate` at line 30872 compares `accessible_text_default(node)` with `visible_virtual_default(virtualNode, false, false, ...)`. The latter recursively collects all visually visible descendant text (line 21326). The rule normalizes/tokenizes that text and requires the label tokens to be a contiguous subsequence of the name tokens. It does not add accessible descriptions to the name. Visually visible `aria-hidden` descendants are still included. Therefore neither `aria-describedby` alone nor hiding metadata from AT repairs this structure correctly.

Working repository pattern: `PeopleTable` renders `PersonAvatar`, department/title/scoring cells **outside** the real name-only button, which has the same exact `${name} 상세 보기` accessible name. `PersonAvatar` separately exposes meaningful photo `alt` or fallback `role="img"`/accessible name. Its implementation should remain untouched.

### Smallest justified semantic candidate

Use the same label-versus-metadata separation in the chart, retaining the existing visual layout:

1. Make the existing visual card/row wrapper `relative`.
2. Keep a real button whose visible contents are its label only: department name, `상위 미지정`, or person name. Keep its requested `aria-label`, `aria-expanded`, `aria-controls`, `aria-current`, event handler, and `org-person-*` ID/finder/Drawer trigger contract. Root confirmed `[data-person-id]` is a card-container contract and may move to the visual `li`; exact-name button locators stay unchanged.
3. Put counts, person title/scoring badge, and person Avatar as **siblings** of the label button within the visual wrapper. Point the button's `aria-describedby` to the visible count/title/scoring elements with stable IDs. Keep Avatar accessible as in the working list pattern; no metadata `aria-hidden` workaround.
4. Stretch the real button's pointer hit target over its wrapper using an empty absolute inset pseudo-element. Put the keyboard focus ring on that same full wrapper area through the button's focus-visible pseudo styles. Preserve card highlight/hover/current styles on the visual wrapper as required. This keeps full-card clicks, native keyboard behavior, one focus stop and real onSelect trigger; do not add role-button wrappers or duplicate tab stops.
5. Preserve `그룹 N개` and `팀 N개` bundle buttons: they already derive their full visible label and are absent from the failure receipt. Move only the unknown-summary count portion out of its button, keeping the summary heading readable.

The exact class placement is still a candidate until RED/GREEN browser evidence proves the stretched hit region and focus outline. No source implementation is claimed here.

## B. Left-pane vertical geometry: measurement gate

Current aside is `sticky top-18 max-h-[calc(100dvh-6rem)] ... overflow-y-auto`. It starts after the AppShell topbar, AppPage padding/title/actions, summary and gaps. The observed approximate top 190px plus allowed 904px at viewport height 1000px plausibly explains the 1110px full-page screenshot. The current maximum subtracts 96px without accounting for the actual pane start. Horizontal overflow checks currently cover a different requirement and cannot settle this.

After root GO, measure the actual app with sidebar open at **1440×1000 and 1280×1000**, plus existing component widths at height 900 if needed. Record:

- aside `getBoundingClientRect()` top/bottom/width, `clientHeight`, `scrollHeight`, computed max-height/overflow/sticky top;
- `window.innerHeight`, documentElement/body/scrollingElement clientHeight and scrollHeight, document scroll position;
- selected team/card count and selected-region bottom, using the observed small 5-person team so right-card height does not confound the test;
- a wheel gesture over the pane away from its scroll boundaries: pane scrollTop must increase while document scroll position remains unchanged; reach the last tree row within the pane;
- document vertical overflow and pane bounds before/after, and current 1440 four-column/1280 three-column geometry.

If confirmed, first candidate is **only the aside maximum height**, subtracting the measured desktop page stack and required bottom padding instead of 6rem (approximately 14rem, subject to both measured widths). Keep sticky behavior for right-side long content. Prefer a scoped CSS/class correction; do not introduce resize observers or redesign AppShell. If a fixed scoped offset cannot reliably satisfy the actual geometry, report that evidence and ask root to extend file scope before altering shared AppPage/AppShell. Do not assert a vertical PASS from the existing horizontal test or screenshot alone.

## Meaningful regression and file ownership plan

Product file: `web/components/people/org-chart.tsx` only. Primary regression file: `web/components/people/org-chart.browser.test.tsx`.

Before the product fix, add and run actual browser regressions that fail on f579:

- Preserve the already executed, unchanged real E2E default whole-document axe failure as the failing accessibility regression. Its recorded f579 RED is 41 nodes across the real division/team counts, unknown-summary and cards. Root QA reruns that exact chart case after the fix for GREEN, still using installed axe 4.14 and `axe.run(document)` default rules/context. Do not add a package, loader, modified axe context or duplicate regression harness.
- Assert exact accessible names and readable descriptions of the actionable controls, visible count/title/scoring text, and accessible sibling Avatar. Click card title/scoring/Avatar areas to prove stretched pointer coverage. Keep Enter and add Space activation/focus return coverage; require existing finder/card/URL/bundle tests to continue passing.
- Add a realistic long-tree/small-selected-team geometry regression with an AppShell-height header fixture at 1440/1280. Assert approximately 300px pane, viewport-contained pane bottom, internal overflow, no document vertical overflow attributable to the tree, and actual independent pane scrolling. Keep the existing 4/3-column and 44px Avatar assertions. Do not use the existing 80-card default fixture for the no-document-overflow assertion.

**Root ruling received during preparation:** existing full default whole-document E2E f579 RED41 is the failing axe regression; preserve it unchanged and root QA reruns the same chart case for GREEN. Add meaningful component RED→GREEN coverage for accessible descriptions, whole-card pointer behavior, Enter/Space/focus, and pane overflow only. No vitest config/axe loader/new package/QA-owned source changes are authorized or required. Root QA can add a narrow actual-layout assertion after freeze if needed. This supersedes the earlier loader/file-ownership question sent during investigation.

After RED is confirmed, implement one semantic correction, run that regression GREEN, then verify the independently confirmed layout correction RED→GREEN. Run focused OrgChart browser/component checks and the repository-required verification/normal commit gate once root authorizes the execution scope. Save raw commands/logs, changed paths, protected tracked-byte comparison against f579, and normal new commit SHA here. Do not amend, bypass hooks, rerun unchanged Auth95/full30, or claim live acceptance; root assigns the affected fresh live checks.

## Read-only preparation evidence

Read the binding brief; approved design §5/§7/Appendix A; owned UI spec; docs/CLAUDE, README and implementation constraints; conventions/testing/design-system/Vercel React skills; installed Next16 accessibility guidance; exact actual safe axe JSON/index; current OrgChart/browser tests/PersonAvatar/PeopleTable/AppPage/AppShell/root layout; existing QA axe loader and assertions; installed axe matching/evaluation/text traversal implementation. Systematic-debugging phase 1–2 completed for finding A. Finding B remains a hypothesis awaiting authorized actual DOM measurement. No tests or runtime commands executed.

## Root GO and scoped implementation

Root released the source/runtime freeze after QA cleanup/integrity and explicitly authorized only `org-chart.tsx` + `org-chart.browser.test.tsx`, real component regression, focused browser checks, and a normal new commit gate. No DB/app/Auth/live-QA runtime, full verify, Auth95/all30, packages/config, or other tracked files are authorized. Root reports historical final f579 live **26 PASS / 4 FAIL** (two chart axe, detail120s, list1280 next5s); this continuation makes no causal claim about the other two failures. Cursor8 PASS is root QA evidence, not work repeated here.

Implemented the semantic separation described above with a smaller department implementation: department buttons retain their full row size; their described count is a positioned sibling over the button with `pointer-events-none`, so count clicks still activate the real native button. Selected count color follows the real button's aria-current. Unknown-summary and person buttons use stretched empty pseudo-element hit areas. Person Avatar/title/scoring remain accessible visible siblings; person names are unchanged. `data-person-id` moves to the visual `li`; `org-person-*`, exact names, trigger element, and `data-highlighted` remain on the button. Card highlight styles remain on the visual card. No finder effects/timer/dependencies or shared Drawer/Avatar code changed.

The real component reproduction confirmed finding B at both widths, so the aside maximum now reserves 14rem for the existing page stack and bottom padding. No AppShell/AppPage changes or JavaScript measurements/observers were introduced. Actual-app post-fix DOM measurement remains root QA's responsibility.

### Commands and observed RED → GREEN

All raw logs are beside this report in the ignored SDD directory.

1. Added regression/guard tests before product edits. Command:

   `VITEST_MAX_WORKERS=2 pnpm -C web exec vitest run --config vitest.browser.config.ts components/people/org-chart.browser.test.tsx`

   `live-ui-browser-red.log`, exit 1: **3 FAIL / 23 PASS**. Missing description failed first; geometry independently failed at both widths. Both actual component measurements: viewport 1000, pane top182/bottom1086/client904/scroll2093, document height1110.

2. Split the static metadata descriptions into independently reported regressions before product edits; same command:

   `live-ui-browser-red-independent.log`, exit 1: **7 FAIL / 24 PASS**. All five count/title/scoring descriptions empty (division, selected team, unknown summary, scoring person and non-scoring person); both pane-bounds failures reproduced. Pointer and Enter/Space/Drawer guards already passed, as expected. The product source was still f579 for both RED runs.

3. Implemented only the two owned paths; formatted with:

   `pnpm -C web exec prettier --write components/people/org-chart.tsx components/people/org-chart.browser.test.tsx`

   Same focused browser command: `live-ui-browser-green.log`, exit 0, **31/31 PASS**. No expectations were weakened after RED.

4. Added an extra full visual-card viewport-bounds assertion to the existing finder flow because the name button now has smaller intrinsic bounds. Targeted command ending `-t 'finds at most8'`: `live-ui-finder-bounds-before.log`, exit 0, **1 PASS / 30 filtered**. It passed immediately, so this guard is not represented as a new RED; no evidence justified changing finder behavior and its effects remain untouched.

5. After the final reserve-height comment and selected-count color preservation, ran final evidence command:

   `VITEST_MAX_WORKERS=2 pnpm -C web exec vitest run --config vitest.browser.config.ts components/people/org-chart.browser.test.tsx --reporter=verbose --silent=false`

   `live-ui-browser-final-green.log`, exit 0: **31/31 PASS**, no skipped cases in the complete focused run. Actual logged component metrics at both1280/1440: viewport1000, pane top182/bottom958/client776/scroll2093, document height1000. Assertions also prove wheel input increases pane scrollTop without changing window scrollY, last tree row reachable within pane, width300, no horizontal overflow, existing 3/4 card columns and 44px Avatar, exact names, visible/accessible metadata, Avatar/title/scoring physical click activation, Enter and Space shared Drawer opening/Escape focus return, finder focus/highlight/bounds and existing M3 expiry, URL/history and bundles.

6. `git diff --check` passed. `git status --short` lists exactly the two owned paths. `git diff --name-only f579a2a6b27fb0ab05650179aba6609a5fb07182 -- . ':(exclude)web/components/people/org-chart.tsx' ':(exclude)web/components/people/org-chart.browser.test.tsx'` printed nothing: all other tracked worktree paths remain f579-identical before commit. Normal commit/gate receipt follows below.

### Pending handoff boundaries

No fresh whole-document axe GREEN, production build, full verification or actual-app geometry claim is made. Root owns scoped review and final full verification/affected live QA, including unchanged chart axe case. Historical f579 axe41 and all its live failures remain retained.

## Normal commit and integrity handoff

Committed **`cc5c45bdd8e6e27627e745d0f33f04aaf9918a4f`**, direct parent frozen f579, message `fix: 조직도 버튼 설명과 트리 스크롤 보완`. Exactly two owned paths, 212 insertions/69 deletions. No amend/bypass.

Command:

`VITEST_MAX_WORKERS=2 NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:1 NEXT_PUBLIC_SUPABASE_ANON_KEY=placeholder git commit -m 'fix: 조직도 버튼 설명과 트리 스크롤 보완'`

`live-ui-commit-gate.log`, **exit0**: normal policy check, full web format check, Next typegen + TypeScript, ESLint, lint guards, **998/998 unit tests in62 files**, Lodestar both rules, token and color checks all passed, then normal commit succeeded. These are the unmodified required quick commit checks; no production build/full verify/Auth95/live30 was run by this owner.

`live-ui-byte-proof.log`, **exit0**: asserted direct parent=f579, changed path set equals exactly the two owned paths, empty `git status --porcelain`, worktree equals HEAD. **All other1081 tracked paths are identical to frozen f579**. Separate direct prefix comparison confirms all OrgChart logic/effects before its AppPage render are byte-identical to f579 (finder including M3 state/timer/effects unchanged). Protected server/API/Auth/data/photos/SQL/generated types/tokens/packages/guardrails/shared Drawer/shared Avatar/I1 files therefore remain unchanged.

Ready for root's scoped review of f579..cc5c45b and root QA's authorized final verification/affected live evidence. This is a completed scoped implementation handoff, not a full Task4/live-acceptance PASS.

## Scoped review follow-up: summary-count held press

Root authorized one concrete new-diff concern from review, same two-file ownership: shared Button's `active:not-aria-[haspopup]:translate-y-px` could establish a containing block while the unknown-summary pseudo-element is stretched to its h2, shrinking the hit area before pointer release. No broad review, services/DB, live-QA or full verify was authorized or performed.

Added a real physical press regression at1280/1440. It uses native Playwright-backed `userEvent.click` with a300ms down/up delay at a visible count text fragment **outside the label button's intrinsic rectangle**. `force` only lets the browser send physical input at the visible metadata coordinate despite its deliberate overlaid button hit area; no synthetic dispatch or button.click is used. A mousedown observer measures the held active CSS/pseudo bounds and actual `elementFromPoint` after200ms, and mouseup records its real target. The test requires count-area collapse and reopen, unchanged exact name/description, held target continuity and release on the real button.

RED command (product still cc5c45b):

`VITEST_MAX_WORKERS=2 pnpm -C web exec vitest run --config vitest.browser.config.ts components/people/org-chart.browser.test.tsx -t 'toggles the unknown bundle by pressing' --reporter=verbose --silent=false`

`live-ui-summary-press-red.log`, **exit1:2 FAIL/31 filtered**. Both widths: label rectangle x288..387.140625, y443..483 (width99.140625), heading x288..571 (width283), physical count point **(404.8828125,465)**. During the held press active=true, translate approximately1px, pseudo-element shrank to **97.1406×38px**, `elementFromPoint` was no longer the button and mouseup did not target the button. `aria-expanded` incorrectly remained true, so collapse failed. This is a measured new-diff regression, not speculation.

Minimal production correction: one local utility on the unknown-summary Button, **`active:not-aria-[haspopup]:translate-none`**. It overrides the shared active move for this stretched button only. Zero-pixel translate would still establish a containing block; CSS `translate:none` preserves the h2 containing block. Shared Button and plain person button code remain unchanged.

Formatted the same two owned files with the earlier Prettier command, then GREEN command:

`VITEST_MAX_WORKERS=2 pnpm -C web exec vitest run --config vitest.browser.config.ts components/people/org-chart.browser.test.tsx --reporter=verbose --silent=false`

`live-ui-summary-press-green.log`, **exit0:33/33 PASS**, complete focused file, no filtered cases. At both widths, both physical count presses (collapse and reopen) record active=true, translate=none, pseudo-element **283×40px**, held hitIsButton=true and releasedOnButton=true; exact name/description remain correct. All prior31 guards remain green, including pane metrics958/776/1000 and prior I1/M3 unchanged scope. `git diff --check` passed. New normal commit/gate and protection receipt follow.

Follow-up committed **`cd4a91c673fcd411a31e8f86086a5bb429918fde`**, direct parent cc5c45b, normal new commit `fix: 조직도 요약 클릭 영역 유지`, exactly two owned paths79 insertions/1 deletion. Command used the same allowed workers2/inert public env and `git commit -m 'fix: 조직도 요약 클릭 영역 유지'`; no amend/bypass. `live-ui-summary-commit-gate.log` **exit0**: policy, format, Next typegen + TypeScript, full ESLint, lint guards, **998/998 unit tests in62 files**, both Lodestar rules, tokens and colors all passed, then normal commit succeeded.

`live-ui-summary-byte-proof.log` **exit0** asserts direct parent cc5c45b, exactly the two owned changed paths relative to both cc5c45b and frozen f579, all other **1081 tracked paths identical to both baselines**, clean working tree, and all OrgChart pre-render logic/effects still f579-identical. Source follow-up is only the one active-translate utility; regression code is the two-width held physical count press guard and metrics. Root may complete the same scoped review; no further code changes or live-runtime checks were run by this owner.
