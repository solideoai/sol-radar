# Final whole-branch review — 89b2b5e..1f9c748

**Spec compliance: NEEDS FIXES; final acceptance is not established.** The guarded read-only role/API/list/standalone-chart implementation has substantial source and real-stack evidence, but the explicit whole-page axe0 requirement currently fails. The brief finder highlight/focus behavior also has a minor defect.

**Quality/readiness: WITH FIXES; not ready to merge or declare complete.** No concrete authorization/RLS bypass, immutable-input alteration, or Critical issue was found in this review. Resolve I1 and preferably M3 in the single consolidated product-fix wave, obtain a scoped review, then complete fresh final-SHA verification and evidence audit. This is not merge, shared-DB, push, or deployment approval.

## Scope and review provenance

- Only checkout: `/Users/leegwanghui/.codex/worktrees/5b0c/sol-radar`, branch `feat/people-read`, clean HEAD `1f9c748abb2c010449f627ca7d177232d74d444b`; base `89b2b5eef020d35de0f8ce93c2c3c12004645b66`. Fixed package: `review-89b2b5e..1f9c748.diff`, 10 commits, 66 paths, 359922 bytes.
- This completes the SAME unfinished whole-branch review after external model capacity failure. The predecessor's recorded milestone says it inspected all production role/API/cursor/SSR/list/chart/Drawer/Avatar changes and SQL/grant context, found no concrete auth/RLS bypass or immutable-data change, and independently confirmed the AppShell landmark and finder-expiration issues. That work is attributed to the predecessor; I did not repeat every production read.
- I read the continuation/brief, binding read/UI specs, candidate Task4 report, Task1/2 approvals and Task3A review/fix approval. I completed the remaining browser/E2E assertion and fixture review, checked safe JSON and raw log excerpts, and checked current source specifically for landmark composition and finder lifecycle. The findings below are independently substantiated by those source checks and evidence. No additional concrete production defect emerged from the remaining checks.
- No tests, build, runtime, DB, .env access, other-worktree operations, or subagents were used. No private traces, auth states, or raw headers were opened. Only this ignored report was written. Logged historical observations of other worktrees are evidence, not new live checks of those worktrees.

## Strengths and cross-task alignment

- The additive business role remains distinct from organization owner/member and platform admin. Task1's independent review checked the preexisting column-grant context as well as the new REVOKE, avoiding the false assumption that column REVOKE defeats table grants. Task1/2 reviews and the predecessor's production pass found the server-current-org/session/RLS path consistent with the approved contract.
- API/domain tests exercise public DTO projection, 200-person pagination and 27/173 detail behavior, normalized strict UUID queries, malformed Bearer precedence, role/current-org gates and authenticated cursors. Live QA adds actual user-token REST/RLS and denied-write evidence; SDK-mocked route tests are not presented as live RLS proof.
- The approved Task3A separation is reflected in tests: `/people` stays list-only and ignores legacy `view`; `/org-chart` uses the full guarded directory, actual parent links, derived counts, catalog/name ordering, valid/default team URLs, and shared Drawer/Avatar. The former missing unknown-bundle disclosure was fixed and independently approved. Prior Task3 tab/catalog-shell findings are resolved according to that scoped review, not silently omitted.
- The browser tests check real DOM visibility, keyboard finder selection, containing-bundle reopening, focus return, Drawer geometry and stale-response rejection. The component chart's mocked history and reserved sidebar space are clearly narrower than live composed Next acceptance (`web/components/people/org-chart.browser.test.tsx:14`, `:338`).
- E2E `assertAxe` runs `axe.run(document)` with default rules and attaches the actual violations (`web/e2e-auth/support/people-read-cases.ts:172`). The 1f9c focus correction polls actual `dialog.contains(document.activeElement)` after each Tab (`:504`); it does not accept a sibling focus guard or weaken the timeout. Exact P&AX naming and retaining the real opener handle correct test oracles while preserving the original assertions. The two-file diff and receipt agree that production bytes remain identical to 176471d.
- The QA fixture provisions exact owned users/foreign organization and cleans those IDs, preserves the normal five users/core hashes, and records proof (`web/e2e-auth/support/people-fixtures.ts:196`, `:225`). Successful authenticated feature setup deliberately navigates after login; it does not claim automatic login redirect coverage, which belongs to the unchanged Auth95.

## Issues

### Critical

None found.

### Important — I1: Composed AppShell leaves sidebar content outside landmarks

**References:** `web/components/app-shell.tsx:107`, `:108`, `:130`, `:157`, `:178`; sidebar primitives are plain divs at `web/components/ui/sidebar.tsx:204`, `:322`, `:333`.

Only the middle main-menu list is enclosed by the existing navigation landmark. The company-name header and footer/user-menu content sit outside it, and the outer desktop Sidebar has no landmark semantics. The actual 1f9c 1440px list run reports one default axe `region` rule violation with two nodes: the company-name span and a footer sidebar-menu ul. The safe raw attachment corroborates the source; this is a real composed-page defect, not the earlier immediate-focus oracle failure.

**Impact:** Users navigating by landmarks do not get complete sidebar coverage, and the explicitly required default whole-page axe0 gate fails. Axe labels this moderate/best-practice; it is an Important acceptance blocker, not a Critical security defect. Some uncovered shell content predates this feature; the feature's composed-page acceptance requirement still applies.

**Correction:** Add appropriate semantic landmark coverage around all sidebar header/content/footer material in the AppShell composition, with useful distinct accessible names where needed. Preserve the existing main navigation and footer ordering and keep this within the approved shell scope. Cover the composed shell and retain whole-document default axe checks on both routes. Do not suppress/exclude `region`, narrow the axe context to the Drawer, or redesign N1.

**Evidence:** External QA root, `safe-evidence/actual-axe-list-1440-1f9c748abb2c.json`; `people-fixed5-1f9c748abb2c.log` fails at the final list-page axe assertion (`people-read-cases.ts:535`). The earlier Drawer attachment has an empty violations array. Fix status: OPEN.

### Minor — M3: Finder intent survives its intended expiry after leaving the team

**Reference:** `web/components/people/org-chart.tsx:87` (effect), `:90` (early return), `:93` (timer), `:95` (team dependency).

Finding a person sets `focusedPerson` and starts a 1600ms expiration. Switching teams before expiration runs cleanup and cancels that timer. The next effect cannot find the absent card and returns without clearing the intent or scheduling expiration. Returning to that team later focuses, scrolls to, and highlights the old person again.

**Impact:** An old search can unexpectedly take focus from current navigation and repeat what the specification calls a brief highlight. This is a bounded interaction defect; no data or authorization impact was found.

**Correction:** Make intent expiry independent of whether its card/team is currently rendered, or explicitly clear the intent when leaving its team. Preserve initial finder-to-team focus. Add a regression for find → switch away before 1600ms → wait past expiry → return, asserting no stale refocus/highlight. Neither the component finder test nor the live chart case currently covers this sequence. Recommended in the same product-fix wave; status OPEN.

### Minor / informational — naming warnings do not imply missing behavioral coverage

- `web/server/organization/business-access.model.ts:1`: Task1's archived gate warned about the missing sibling test name. Its runtime role enum, all four values and invalid-role denial are exercised through `business-access.service.test.ts:40` and `:77`. No duplicate mirror test is necessary merely to satisfy the name heuristic. A convention-compatible organization can be considered separately; no checker weakening.
- `web/server/people/people.test-data.ts:1`: Task2's archived gate warned about this test-only helper's sibling naming. It has test consumers, no production callers, and its projections are exercised by model/service tests. Rename/place it under the established test-helper convention if removing the warning; do not add a vacuous helper-only test or relax the guard.

These are nonblocking historical warning triage. The inspected final 176/1f9c architecture receipts report zero warnings; do not imply these historical warnings are fresh final failures.

## Actual evidence and its limits

External evidence root: `/Users/leegwanghui/dev/hackathon/sol-radar-inputs/people-read-20261018/qa`.

| Origin | Evidence checked | Supported conclusion |
|---|---|---|
| 176471d | `verify-176471d11dde.log` | Fresh root358/358, web998/998 and production Next build including `/org-chart` PASS; final exit0. |
| 176471d | `normal-auth-176471d11dde.log`, `normal-public-176471d11dde.log` | Unchanged normal Auth95/95, public138/138, browser152/152 PASS. This is the production build/regression origin, not a new 1f9c full run. |
| 176471d | `people-176471d-checkpoint.json`, test source, `people-pending13-176471d11dde.log` | Distinct new29 at176: 24PASS/3 oracle FAIL/2NOTRUN. Actual last13 passed, including all200 image HTTP/MIME/SHA/decode, API/account-state/RLS and denied-write cases. |
| 1f9c748 | `qa-fix1-commit-receipt.json`, two-file git diff, `qa-fix1-commit.log`, `task3a-qa-fix1-drawer-browser-attempt1.log` | Only two test files changed (+12/-6); all other tracked bytes identical176. Normal gate998 and focused Drawer10 PASS. No fresh full build/Auth/public run is claimed. |
| 1f9c748 | `people-fixed5-1f9c748abb2c.log`, actual axe attachments | First affected case fails on real list-page `region`; four cases did not run in that attempt. Prior assertions, including actual480px/bounds, Tab containment, Draweraxe0, Escape, filters and27 paging, reached and passed before that failure. |
| 1f9c748 | `people-stale-only-1f9c748abb2c.log` | Corrected stale/removed-trigger case1/1PASS, including Escape → list heading after removal. This does not retroactively pass the176 case. |

Across this product-identical/test-only lineage, the current unique-case picture is **25PASS / 1 real FAIL / 3 UNVERIFIED** (1440 chart, 1280 chart, 1280 list). It is not29/29 at one SHA. The old c17882PASS/13FAIL Auth result, earlier DrawerAbortError, and the176 original oracle failures remain historical facts. Fresh176 Auth95 passing is not evidence that old failures were caused only by load, nor that auth product code was fixed.

Data evidence is consistent: all219 entries in `frozen-preflight-176471d11dde.json` report matching base89b2b5e, including200 PNGs, old12 SQL and the scoring model/test inputs; the1f9c receipt preserves those bytes. `db-state-candidate-postqa-1f9c748abb2c.json` records13 migrations, global200people/27scoring/Auth5 and org01 core48/12/200/27 semantic hashes. Candidate cleanup records stable normal IDs/post-normal memberships, all defaultVIEWER, no normal org01 memberships, zero temporary users/foreign rows and no app listeners. Owned Supabase remains intentionally retained. These are inspected receipts, not a new DB query by this reviewer.

The live source assertions cover all38 team selections/200 unique people, catalogs/hierarchy/13known81 plus25unknown119/4empty groups, four real roles, current-org authority, foreign404/RLS0, no-auth denial and denied writes. The 200-photo safe aggregate is expressly derived from the successful test, whose source asserts each actual response and decode; it is not a per-image raw response log. I also viewed the safe1440 Drawer screenshot: readable right-hand sheet, expected portrait/name and close focus ring; this one view does not establish chart/1280 visual acceptance.

## CannotVerify / final Task4 actions

1. **Fresh composed desktop acceptance:** After the consolidated fix, run the complete final frozen-SHA live cases, including all chart/list assertions at1440 and1280, default whole-page axe0, open sidebar/no overflow, actual3/4 columns,44px avatars/card order, finder/bundle/deep-link/reload/Back/Forward, shared Drawer keyboard/trap/restore and screenshots. Prior role header/all-team traversal and mocked component coverage do not substitute for the three currently unverified cases. Retain per-image HTTP/SHA/decode attachment before HTML report replacement.
2. **Fresh regression/build provenance:** The post-product-fix SHA needs full `pnpm verify`, unchanged normal Auth95/public138/browser suites and new29 as authorized, with exact-SHA/owned-target receipts and unchanged assertion budgets/rules. The176 build cannot be labeled a post-fix build. Preserve initial failure logs when adding fresh successes.
3. **Signed runtime cursor probes:** Actual tamper/filter/limit/foreign-token rejection and pagination have evidence. Exact24h boundary/older/future timestamps, re-signed real foreign-org/filter payloads and runtime missing-secret503 probes remain NOT RUN. Complete prepared external probes with honest regression-source/runtime-source provenance; do not present unit coverage or an unexecuted script as live proof.
4. **Precisely scoped denial coverage:** The new live tests cover suspended403 APIs and suspended user-token RLS0. The composed SSR account-state loop at `web/e2e-auth/people.write.spec.ts:175` covers noorg/multiple/incomplete, not suspended. Obtain an explicit receipt for a suspended session visiting both new routes, or retain that narrow dynamic behavior as unverified. This is a coverage caveat, not evidence of a source bypass. Invalid-business-role SSR uses the controller-approved inline HTTP200 denial; do not claim it returns verified403. Its source/unit coverage is distinct from live API401/403 receipts.
5. **Immutable/cleanup audit:** At the final SHA, retain final core/portrait/input hashes, real200/27/173 and hierarchy totals,13-migration ledger, normalAuth5 identity/post-normal membership preservation, exact owned-fixture cleanup and port/process receipts. Keep DB ownership and retained/cleanup state explicit. No shared DB access or broad cleanup.

## Declined to judge

- Full N1 navigation/ops/P1, CRUD/retirement/reallocation/simulation, mobile and payments: outside the approved read-only work; no expansion requested by this review. Landmark correction is within required composed-page accessibility.
- G1–G10/score_runs live pipeline completion: explicitly excluded/unverified; preserved94/72/68 input bytes do not establish runtime pipeline execution.
- Compatibility with externally advanced main `1e7e081...` and its concurrent work: outside this frozen base89 branch review; no latest-main merge/rebase/integration tests occurred. Any later authorized integration requires its own conflict/verification evidence.
- Deployment/cloud migration/merge/push: no authorization and no readiness conclusion for those operations.

## Consolidated recommendation

One product-fix wave: I1 landmark composition plus M3 expiration lifecycle, with focused behavioral regressions and no rule suppression, new domain/API/SQL/package or N1 scope. Then one scoped re-review of those changes and fresh complete final-SHA Task4 evidence. Naming warnings are informational and need not expand the product patch. No second broad review is requested by this report.
